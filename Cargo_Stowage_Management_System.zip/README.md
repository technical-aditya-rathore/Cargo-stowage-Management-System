# Cargo Stowage Management System

## Overview
This project provides an AI-powered Cargo Stowage Management System designed to optimize cargo arrangement in space missions. The system ensures efficient space utilization, prioritizes critical items, and minimizes waste.

## Features
- Intelligent item placement using heuristic algorithms
- Priority-based scheduling
- Waste detection for unused items
- Simulation of time-based item usage
- REST API and React dashboard

## Technologies
- Python + FastAPI
- React + Tailwind CSS
- Docker (for deployment)
- Custom Heuristic Algorithms

## Setup
1. **Backend**:
```bash
cd backend
uvicorn main:app --reload
```

2. **Frontend**:
```bash
cd frontend
npm install
npm run dev
```

## API Endpoints
- `/api/place`: Place items into containers
- `/api/simulate/day`: Simulate a day's usage
- `/api/waste/identify`: Detect wasted items
- `/api/logs`: Fetch operation logs
- `/api/export/arrangement`: Export cargo layout

## Team
Developed for National Space Hackathon 2025
