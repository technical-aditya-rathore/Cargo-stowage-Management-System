
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import axios from 'axios';

export default function Dashboard() {
  const [logs, setLogs] = useState([]);
  const [items, setItems] = useState([]);
  const [waste, setWaste] = useState([]);

  const fetchLogs = async () => {
    const res = await axios.get('/api/logs');
    setLogs(res.data);
  };

  const placeItems = async () => {
    await axios.post('/api/place');
    fetchLogs();
  };

  const identifyWaste = async () => {
    const res = await axios.get('/api/waste/identify');
    setWaste(res.data);
  };

  const simulateDay = async () => {
    await axios.post('/api/simulate/day');
    fetchLogs();
  };

  const fetchItems = async () => {
    const res = await axios.get('/api/export/arrangement');
    const flat = Object.values(res.data).flatMap(container => container.current_items);
    setItems(flat);
  };

  return (
    <div className="grid grid-cols-1 gap-4 p-4">
      <Card>
        <CardContent className="p-4 flex flex-col gap-2">
          <h2 className="text-xl font-bold">Actions</h2>
          <Button onClick={placeItems}>Place Items</Button>
          <Button onClick={simulateDay}>Simulate Day</Button>
          <Button onClick={fetchItems}>Show Placed Items</Button>
          <Button onClick={identifyWaste}>Identify Waste</Button>
          <Button onClick={fetchLogs}>View Logs</Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-2">Logs</h2>
          <ul className="list-disc pl-4">
            {logs.map((log, i) => (
              <li key={i}>{log.event} - Day {log.day}</li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-2">Placed Items</h2>
          <ul className="list-disc pl-4">
            {items.map((item, i) => (
              <li key={i}>{item.name} (Priority: {item.priority})</li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-2">Waste Items</h2>
          <ul className="list-disc pl-4">
            {waste.map((item, i) => (
              <li key={i}>{item.name}</li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
